package mobi.acpm.inspeckage.hooks.entities;

import java.util.List;

/**
 * Created by acpm on 29/04/17.
 */

public class FingerprintList {

    public List<FingerprintItem> fingerprintItems;

}
